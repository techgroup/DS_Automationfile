﻿using AgeRangerWebUi.Steps;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace AgeRangerWebUi.Utilities
{
    [Binding]
    public class Hooks : BaseClass
    {
        public IWebDriver Driver { get; private set; }

        [BeforeScenario]
        public void BeforeScenario()
        {
            Driver = DriverFactory.InitiateWebDriver(CommonConstants.DriverSettings.ChromeBrowser);
        }

        [AfterScenario]
        public void AfterScenario()
        {
            Driver.Quit();
        }
    }
}
