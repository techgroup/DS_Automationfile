﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System.Collections.Generic;
using AgeRangerWebUi.Utilities;
using OpenQA.Selenium.Remote;
using AgeRangerWebUi.Steps;

namespace AgeRangerWebUi.PageFactoryObjects
{
    public class AgeRangerMainPage 

    {
       private  RemoteWebDriver _driver;
       private IWebDriver driver;

        public AgeRangerMainPage(RemoteWebDriver driver) => _driver = driver;

        public AgeRangerMainPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        // public AgeRangerMainPage(IWebDriver driver)
        //  {
        //  PageFactory.InitElements(driver, this);

        //  }

        public IWebElement SearchTextField => _driver.FindElementById("SearchText");
        public IWebElement FirstName => _driver.FindElementByXPath("//input[@name='FirstName']");
        public IWebElement LastName => _driver.FindElementByXPath("//input[@name='LastName']");
        public IWebElement Age => _driver.FindElementByXPath("//input[@name='Age']");
        public IWebElement PeopleTable => _driver.FindElementByXPath("//table");

        public IList<IWebElement> ExistingUserName => _driver.FindElementsByXPath("//td[@class='col-md-7 ng-binding']");
        public IList<IWebElement> ExistingUserAge => _driver.FindElementsByXPath("//td[@class='col-md-2 ng-binding']");
        public IWebElement EditPerson => _driver.FindElementByXPath("//a[@ng-click='openEditForm(person)']");
        public IWebElement DeletePerson => _driver.FindElementByXPath("//a[@ng-click='delete(person)']");
        public IWebElement AddPerson => _driver.FindElementByXPath("//a[@ng-click='openNewPersonForm()']");
        public IWebElement FirstNameInlineError => _driver.FindElementByXPath("//p[@class='help-block']");
        
        public IWebElement SubmitButton => _driver.FindElementByXPath("//button[@class='btn btn-primary']");
        public IWebElement CloseButton => _driver.FindElementByXPath("//button[@ng-click='close()']");
        public IWebElement OkButton => _driver.FindElementByXPath("//button[@data-bb-handler='confirm']");
        public IWebElement CancelButton => _driver.FindElementByXPath("//button[@data-bb-handler='cancell']");

        public IWebElement CrossButton => _driver.FindElementByXPath("//button[@class='bootbox-close-button close']");

        // [FindsBy(How = How.Id, Using = "SearchText")]
        // public IWebElement SearchTextField;
        // [FindsBy(How = How.Name, Using = "FirstName")]
        // public IWebElement FirstName;


        //  [FindsBy(How = How.Name, Using = "LastName")]
        //  public IWebElement LastName;

        //  [FindsBy(How = How.Name, Using = "//td[@class='ng-binding']")]
        //  [FindsBy(How = How.XPath, Using = "//input[@name='Age']")]
        //  public IWebElement Age;


        //   [FindsBy(How = How.XPath, Using = "//table")]
        //   public IWebElement PeopleTable { get; set; }

        //  [FindsBy(How = How.XPath, Using = "//td[@class='col-md-7 ng-binding']")]
        //  public IList<IWebElement> ExistingUserName { get; set; }

        //  [FindsBy(How = How.XPath, Using = "//td[@class='col-md-2 ng-binding']")]
        // public IList<IWebElement> ExistingUserAge { get; set; }

        //     [FindsBy(How = How.XPath, Using = "//a[@ng-click='openEditForm(person)']")]
        //      public IWebElement EditPerson { get; set; }

        //  [FindsBy(How = How.XPath, Using = "//a[@ng-click='delete(person)']")]
        //   public IWebElement DeletePerson { get; set; }

        //    [FindsBy(How = How.XPath, Using = "//a[@ng-click='openNewPersonForm()']")]
        //   public IWebElement AddPerson { get; set; }

        //  [FindsBy(How = How.XPath, Using = "//p[@class='help-block']")]
        // public IWebElement FirstNameInlineError { get; set; }

        //  [FindsBy(How = How.XPath, Using = "//button[@class='btn btn-primary']")] // change Name as Xpath
        //   public IWebElement SubmitButton { get; set; } 

        //   [FindsBy(How = How.XPath, Using = "//button[@ng-click='close()']")]
        //    public IWebElement CloseButton { get; set; }

        //     [FindsBy(How = How.XPath, Using = "//button[@data-bb-handler='confirm']")]
        //     public IWebElement OkButton { get; set; }

      //  [FindsBy(How = How.XPath, Using = "//button[@data-bb-handler='cancell']")]
      //  public IWebElement CancelButton { get; set; }

      //  [FindsBy(How = How.XPath, Using = "//button[@class='bootbox-close-button close']")]
     //   public IWebElement CrossButton { get; set; }
    }
}
