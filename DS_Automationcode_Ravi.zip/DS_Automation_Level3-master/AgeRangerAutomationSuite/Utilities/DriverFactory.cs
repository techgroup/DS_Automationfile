﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
using System.IO;
using System.Reflection;

namespace AgeRangerWebUi.Utilities
{
    public class DriverFactory
    {
        public static IWebDriver InitiateWebDriver(string browser)
        {
            IWebDriver driver = null;
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "/Drivers";
            if (browser.Equals(CommonConstants.DriverSettings.ChromeBrowser))
            {
                driver = new ChromeDriver(path);
            }
            else if (browser.Equals(CommonConstants.DriverSettings.FireFoxBrowser))
            {
                driver = new FirefoxDriver();
            }
            else if (browser.Equals(CommonConstants.DriverSettings.FireFoxBrowser))
            {
                driver = new InternetExplorerDriver();
            }


            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(CommonConstants.DriverSettings.DefaultWaitTime);
            //driver.Manage().Window.Maximize();
            return driver;
        }
    }
}
